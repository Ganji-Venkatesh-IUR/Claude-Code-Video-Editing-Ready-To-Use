import React from 'react';
import {Composition} from 'remotion';
import {Reel} from './Reel';

// 22.7 s voice-over + SFX + BGM mix (public/mix.mp3) @ 30fps -> 682 frames, 9:16 Instagram Reel
export const Root: React.FC = () => (
  <Composition id="JobReady" component={Reel} durationInFrames={682} fps={30} width={1080} height={1920} />
);
