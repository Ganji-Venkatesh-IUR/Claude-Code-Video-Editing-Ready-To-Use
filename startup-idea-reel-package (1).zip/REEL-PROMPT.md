# SAME-TO-SAME PROMPT (copy this into a new chat for every new reel)

Attach: `startup-idea-reel-package.zip` + my current Remotion project zip + new reel's voice-over mp3, script, timestamps.

---
I am Ganji Venkatesh (@ganji.venkatesh.ai). Build my next Instagram reel as a ready-to-use Remotion zip for GitHub Codespaces, in my LOCKED "Dark Reality" theme. Reply to me in Tenglish.

INPUTS: I attach the locked package (it contains `src/brand/`, `public/brand/`, `src/reels/_template`, `THEME-LOCK.md`), my Remotion project zip, the voice-over mp3, script and timestamps.

RULES (do not change anything in the theme):
1. Reuse `src/brand/` and `public/brand/` EXACTLY as attached. Do NOT redesign or recolor. Only add a new folder `src/reels/<reel-name>/` + `public/reels/<reel-name>/voiceover.mp3`, and register a new `<Composition>` in `src/Root.tsx` (keep earlier reels registered).
2. Format 1080x1920, 30 fps. Use `ReelShell`.
3. TOP ROW: LEFT = topic TAG chip (STARTUP / BUSINESS / STUDENTS / IT / AI / MONEY / TREND / FACTS / REALITY, pick from my script; add a new tag to `Tag` in `theme.ts` only if needed). RIGHT = my photo watermark pill with handle `ganji.venkatesh.ai`. Thin amber progress bar below. Same on every reel.
4. THEME: background #0B0B0F + grain + vignette, text #F5F5F7, ONE accent amber #FFB020. Fonts Poppins Bold / Inter / JetBrains Mono (bundled). Panel cards #14141B, border #2A2A35, radius 32. No blur, no heavy bounce; fast cuts, quick slide/scale-in.
5. LAYOUT (Instagram safe): visuals y 440-1060, English captions y 1100-1420, bottom 500px clear.
6. CAPTIONS: always ENGLISH, simple basic words, converted from my Tenglish script. Phrase-level sync to the voice (detect speech pauses in the mp3 and use my timestamps as anchors), word-by-word pop, key words highlighted amber with `*word*`.
7. VISUALS: one clear visual per idea (cards, checklists, numbers, UI mockups, icons) in the same card style as `src/reels/startup-idea/Visuals.tsx`. No random stock look.
8. AUDIO: my voice-over + low ambient BGM (`brand/audio/bgm.mp3`, volume 0.12) + soft SFX from `brand/audio/` (pop, tick, whoosh, hit, check, chime, riser) timed to visuals.
9. END: sign-off card with my photo, GANJI VENKATESH, @ganji.venkatesh.ai, "Follow for reality, not motivation".
10. Update `THEME-LOCK.md` if needed. Run `npx tsc`, render stills to check frames before giving the zip.

OUTPUT: one zip that I unzip with `unzip -o` in my repo root (src/, public/ only, under 25 MB, no node_modules/out). Give the composition id and the render command: `npx remotion render <CompositionId> out/<name>.mp4 --concurrency=2 --jpeg-quality=95`.
Be honest about anything you could not verify.
---

If the locked package is NOT attached, rebuild from this spec: colors/fonts/layout above, tag chip at (left 60, top 250, height 72), watermark pill at (right 60, top 244, height 84) with 84px circular photo, amber conic ring, handle in Inter SemiBold 27px; progress bar at top 352, height 6; captions Poppins Bold 68-104px by length, centered at y~1260.
