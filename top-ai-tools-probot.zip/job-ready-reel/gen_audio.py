import numpy as np, wave, os, subprocess, json
from scipy import signal
SR=44100
rng=np.random.default_rng(7)
def env(n,a=0.005,d=None):
    t=np.arange(n)/SR; e=np.minimum(1,t/a)
    if d: e*=np.exp(-t/d)
    return e
def norm(x,p=0.9): m=np.max(np.abs(x))+1e-9; return x/m*p
def whoosh(dur=0.55,lo=300,hi=5000,up=True):
    n=int(SR*dur); x=rng.standard_normal(n); out=np.zeros(n); k=24; L=n//k
    for i in range(k):
        f=lo*(hi/lo)**((i/(k-1)) if up else 1-i/(k-1))
        b,a=signal.butter(2,[f*0.7/(SR/2),min(f*1.4,SR/2-100)/(SR/2)],'band')
        out[i*L:(i+1)*L]=signal.lfilter(b,a,x[i*L:(i+1)*L])
    t=np.linspace(0,1,n); e=np.sin(np.pi*t)**1.5
    return norm(out*e,0.8)
def hit(dur=0.7):
    n=int(SR*dur); t=np.arange(n)/SR
    f=45+110*np.exp(-t*18); ph=2*np.pi*np.cumsum(f)/SR
    x=np.sin(ph)*np.exp(-t/0.22)
    nz=signal.lfilter(*signal.butter(2,900/(SR/2)),rng.standard_normal(n))*np.exp(-t/0.05)*0.6
    return norm(x+nz,0.95)
def pop(f0=520,f1=900,dur=0.16):
    n=int(SR*dur); t=np.arange(n)/SR; f=f0+(f1-f0)*np.minimum(1,t/0.05); ph=2*np.pi*np.cumsum(f)/SR
    return norm(np.sin(ph)*env(n,0.002,0.05),0.8)
def ding(f=1318,dur=0.9):
    n=int(SR*dur); t=np.arange(n)/SR
    x=np.sin(2*np.pi*f*t)+0.4*np.sin(2*np.pi*2*f*t)+0.15*np.sin(2*np.pi*3.01*f*t)
    return norm(x*env(n,0.002,0.25),0.7)
def blip():
    n=int(SR*0.22); t=np.arange(n)/SR
    x=signal.square(2*np.pi*190*t)*0.5+np.sin(2*np.pi*140*t)
    x=signal.lfilter(*signal.butter(2,1400/(SR/2)),x)
    return norm(x*env(n,0.003,0.09),0.7)
def stamp():
    h=hit(0.5); n=len(h); c=signal.lfilter(*signal.butter(2,[1500/(SR/2),6000/(SR/2)],'band'),rng.standard_normal(n))*np.exp(-np.arange(n)/SR/0.03)
    return norm(h+0.5*c,0.95)
def tick():
    n=int(SR*0.05); t=np.arange(n)/SR
    return norm(np.sin(2*np.pi*2200*t)*np.exp(-t/0.01),0.6)
def chime():
    out=np.zeros(int(SR*1.3))
    for i,f in enumerate([523.25,659.25,783.99,1046.5]):
        d=ding(f,0.8); s=int(i*0.09*SR); out[s:s+len(d)]+=d[:len(out)-s]*0.7
    return norm(out,0.7)
def bell():
    n=int(SR*1.4); t=np.arange(n)/SR; x=np.zeros(n)
    for f,a in [(1568,1),(2093,0.6),(2637,0.5),(3136,0.35),(4186,0.2)]:
        x+=a*np.sin(2*np.pi*f*t+rng.random())*np.exp(-t/0.45)
    x*=0.6+0.4*np.sin(2*np.pi*9*t)
    return norm(x,0.7)
def click():
    n=int(SR*0.08); t=np.arange(n)/SR
    return norm((rng.standard_normal(n)*0.4+np.sin(2*np.pi*900*t))*np.exp(-t/0.015),0.8)
def sparkle():
    n=int(SR*1.0); x=np.zeros(n)
    for i in range(10):
        s=int(rng.random()*0.5*SR); f=rng.choice([2093,2637,3136,3951,4699]); m=int(SR*0.3); t=np.arange(m)/SR
        x[s:s+m]+=np.sin(2*np.pi*f*t)*np.exp(-t/0.08)
    return norm(x[:n],0.5)
S={'whoosh':whoosh,'whoosh_down':lambda:whoosh(0.5,5000,300,False),'hit':hit,'pop':pop,'pop_hi':lambda:pop(700,1200),'ding':ding,'blip':blip,'stamp':stamp,'tick':tick,'chime':chime,'bell':bell,'click':click,'sparkle':sparkle}
os.makedirs('audio/sfx',exist_ok=True)
def save(path,x,sr=SR):
    x=np.clip(x,-1,1); 
    if x.ndim==1: x=np.stack([x,x],1)
    w=wave.open(path,'wb'); w.setnchannels(2); w.setsampwidth(2); w.setframerate(sr); w.writeframes((x*32767).astype('<i2').tobytes()); w.close()
cache={}
for k,f in S.items(): cache[k]=f(); save(f'audio/sfx/{k}.wav',cache[k]*0.9)
EV=[(0.14,'hit',1.0),(0.55,'blip',.5),(0.80,'blip',.5),(1.05,'blip',.5),(1.28,'whoosh',.6),(1.9,'ding',.5),
(2.95,'whoosh',.5),(3.10,'pop',.6),(3.30,'pop',.6),(3.50,'pop',.6),(3.92,'stamp',1.0),
(4.78,'whoosh',.6),(5.0,'pop_hi',.6),(5.6,'pop',.5),(6.1,'pop',.5),(7.35,'whoosh',.5),(8.25,'chime',.55),
(8.80,'whoosh',.5),(9.52,'hit',.9),(10.0,'tick',.5),(10.5,'tick',.5),
(10.88,'whoosh',.5),(11.03,'hit',.7),(11.12,'ding',.5),(12.09,'whoosh',.5),(12.24,'hit',.7),(12.33,'ding',.5),
(13.27,'whoosh',.5),(13.42,'hit',.7),(13.51,'ding',.5),
(14.6,'whoosh',.6),(14.95,'tick',.5),(16.40,'whoosh',.6),(16.7,'tick',.5),(17.1,'tick',.5),(17.5,'tick',.5),(17.9,'tick',.5),(17.62,'pop_hi',.6),
(19.08,'whoosh',.6),(19.5,'pop',.5),(20.82,'pop_hi',.7),(21.55,'click',.8),(21.66,'bell',.8),(21.9,'sparkle',.7)]
D=22.7; N=int(SR*D); sfx=np.zeros(N)
for t,k,g in EV:
    s=int(t*SR); x=cache[k]*g; e=min(len(x),N-s); sfx[s:s+e]+=x[:e]
# BGM: pad + soft pulse
t=np.arange(N)/SR; bgm=np.zeros(N)
ch=[[110,130.81,164.81,220],[87.31,130.81,174.61,220],[130.81,164.81,196,261.63],[98,123.47,196,246.94]]
seg=D/4
for i,c in enumerate(ch):
    m=(t>=i*seg-0.4)&(t<(i+1)*seg+0.4); w=np.clip(np.minimum((t-(i*seg-0.4))/0.8,((i+1)*seg+0.4-t)/0.8),0,1)*m
    for f in c:
        for dt in (-0.6,0,0.7): bgm+=np.sin(2*np.pi*(f+dt)*t)*w*0.12
bgm=signal.lfilter(*signal.butter(2,1200/(SR/2)),bgm)
beat=0.625
for b in np.arange(0.3,D,beat):
    s=int(b*SR); k=hit(0.4)*0.35; e=min(len(k),N-s); bgm[s:s+e]+=k[:e]
bgm*=np.minimum(1,t/1.0)*np.clip((D-0.2-t)/1.0,0,1)
bgm=norm(bgm,1.0)
v=subprocess.run(['ffmpeg','-v','error','-i','public/voice.mp3','-f','f32le','-ac','1','-ar',str(SR),'-'],capture_output=True).stdout
voice=np.frombuffer(v,dtype=np.float32).astype(float); voice=voice/ (np.max(np.abs(voice))+1e-9)*0.92
vv=np.zeros(N); vv[:min(N,len(voice))]=voice[:N]
# duck bgm/sfx under voice envelope
ve=np.convolve(np.abs(vv),np.ones(2205)/2205,'same'); duck=1-0.45*np.clip(ve/0.15,0,1)
mix=vv+sfx*0.55*(0.6+0.4*duck)+bgm*0.14*duck
mix=norm(mix,0.95)
save('audio/mix.wav',mix)
save('audio/bgm.wav',bgm*0.9)
subprocess.run(['ffmpeg','-y','-v','error','-i','audio/mix.wav','-ac','2','-b:a','192k','public/mix.mp3'])
json.dump(EV,open('audio/sfx_cues.json','w'))
print('ok',N/SR)
