import React, {useState} from 'react';
import {
  AbsoluteFill,
  Audio,
  Easing,
  Img,
  delayRender,
  continueRender,
  interpolate,
  spring,
  staticFile,
  useCurrentFrame,
} from 'remotion';

/* ---------------------------- THEME ---------------------------- */
const C = {
  navy: '#0A1330',
  navy2: '#14224A',
  navy3: '#1D2F66',
  orange: '#FF7A2F',
  cyan: '#35D0FF',
  green: '#2FE08F',
  red: '#FF4D5E',
  cream: '#F7EBD9',
  white: '#FFFFFF',
  mute: '#9FB0DE',
  yellow: '#FFD24D',
};
const FPS = 30;
const POP = 'Poppins, sans-serif';

/* --------------------------- HELPERS --------------------------- */
const EASE = Easing.bezier(0.22, 1, 0.36, 1);
const prog = (t: number, a: number, d: number) =>
  interpolate(t, [a, a + d], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: EASE});
const lin = (t: number, a: number, d: number) =>
  interpolate(t, [a, a + d], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
const pop = (t: number, a: number) =>
  t < a ? 0 : spring({frame: Math.round((t - a) * FPS), fps: FPS, config: {damping: 11, stiffness: 150, mass: 0.6}});
const lerp = (a: number, b: number, p: number) => a + (b - a) * p;
const stk = (hex: string) => staticFile(`stickers/${hex}.svg`);
const Stk: React.FC<{hex: string; size: number; style?: React.CSSProperties}> = ({hex, size, style}) => (
  <Img src={stk(hex)} style={{width: size, height: size, ...style}} />
);

const Scene: React.FC<{t: number; a: number; b: number; children: React.ReactNode}> = ({t, a, b, children}) => {
  if (t < a - 0.01 || t > b + 0.01) return null;
  const inn = prog(t, a, 0.35);
  const out = 1 - lin(t, b - 0.25, 0.25);
  return <AbsoluteFill style={{opacity: Math.min(inn, out), transform: `translateY(${(1 - inn) * 30}px)`}}>{children}</AbsoluteFill>;
};

/** Title block: lines that appear at given times */
type Line = {text: string; at: number; size: number; color: string; weight?: number};
const Title: React.FC<{t: number; top?: number; lines: Line[]; until?: number}> = ({t, top = 200, lines, until = 999}) => {
  const out = 1 - lin(t, until - 0.2, 0.2);
  return (
    <div style={{position: 'absolute', left: 40, width: 1000, top, textAlign: 'center', opacity: out}}>
      {lines.map((l, i) => {
        const p = prog(t, l.at, 0.4);
        if (t < l.at) return <div key={i} style={{height: l.size * 1.08}} />;
        return (
          <div
            key={i}
            style={{
              fontFamily: POP,
              fontWeight: l.weight ?? 800,
              fontSize: l.size,
              color: l.color,
              lineHeight: 1.08,
              letterSpacing: -2,
              opacity: p,
              transform: `translateY(${(1 - p) * 40}px) scale(${0.9 + 0.1 * p})`,
              textShadow: '0 8px 30px rgba(0,0,0,0.45)',
            }}
          >
            {l.text}
          </div>
        );
      })}
    </div>
  );
};

/** Glass card */
const Card: React.FC<{
  t: number;
  at: number;
  x: number;
  y: number;
  w: number;
  h: number;
  color: string;
  from?: 'right' | 'scale';
  children?: React.ReactNode;
  style?: React.CSSProperties;
}> = ({t, at, x, y, w, h, color, from = 'scale', children, style}) => {
  const p = pop(t, at);
  if (p <= 0) return null;
  const tr = from === 'right' ? `translateX(${(1 - Math.min(p, 1)) * 520}px)` : `scale(${0.7 + 0.3 * p})`;
  return (
    <div
      style={{
        position: 'absolute',
        left: x,
        top: y,
        width: w,
        height: h,
        borderRadius: 40,
        background: 'linear-gradient(135deg, rgba(29,47,102,0.96), rgba(20,34,74,0.96))',
        border: `5px solid ${color}`,
        boxShadow: `0 20px 50px rgba(0,0,0,0.45), 0 0 40px ${color}55`,
        transform: tr,
        opacity: Math.min(1, p * 1.6),
        ...style,
      }}
    >
      {children}
    </div>
  );
};

/* ------------------------- CHARACTER RIG ------------------------- */
type V2 = [number, number];
type Pose = {l: V2; r: V2};
const POSES: Record<string, Pose> = {
  rest: {l: [95, 430], r: [305, 430]},
  stress: {l: [128, 128], r: [272, 128]},
  shrug: {l: [48, 330], r: [352, 330]},
  pointUp: {l: [100, 430], r: [385, 150]},
  point: {l: [100, 430], r: [392, 300]},
  raise: {l: [100, 430], r: [335, 120]},
  chin: {l: [190, 360], r: [228, 190]},
  wave: {l: [100, 430], r: [340, 110]},
  down: {l: [100, 430], r: [372, 380]},
};
type Mood = 'worried' | 'neutral' | 'happy';
type Key = {at: number; pose: string; mood: Mood};
const KEYS: Key[] = [
  {at: 0, pose: 'stress', mood: 'worried'},
  {at: 1.3, pose: 'raise', mood: 'neutral'},
  {at: 2.95, pose: 'shrug', mood: 'worried'},
  {at: 4.78, pose: 'pointUp', mood: 'neutral'},
  {at: 8.3, pose: 'raise', mood: 'happy'},
  {at: 8.84, pose: 'raise', mood: 'neutral'},
  {at: 10.95, pose: 'point', mood: 'happy'},
  {at: 14.6, pose: 'chin', mood: 'neutral'},
  {at: 16.4, pose: 'pointUp', mood: 'happy'},
  {at: 19.08, pose: 'point', mood: 'happy'},
  {at: 21.0, pose: 'wave', mood: 'happy'},
];
const SPEAK: [number, number][] = [
  [0.14, 4.5],
  [4.8, 18.73],
  [19.11, 22.45],
];

const armPath = (sh: V2, hand: V2, side: number) => {
  const cx = (sh[0] + hand[0]) / 2 + side * 26;
  const cy = (sh[1] + hand[1]) / 2 + 46;
  return `M ${sh[0]} ${sh[1]} Q ${cx} ${cy} ${hand[0]} ${hand[1]}`;
};

const Char: React.FC<{t: number; left: number; top: number; scale?: number; rim?: boolean}> = ({t, left, top, scale = 1, rim}) => {
  let idx = 0;
  KEYS.forEach((k, i) => {
    if (t >= k.at) idx = i;
  });
  const cur = KEYS[idx];
  const prev = KEYS[Math.max(0, idx - 1)];
  const b = idx === 0 ? 1 : prog(t, cur.at, 0.45);
  const pp = POSES[prev.pose];
  const pc = POSES[cur.pose];
  const wig = cur.pose === 'wave' ? Math.sin(t * 11) * 18 : 0;
  const lh: V2 = [lerp(pp.l[0], pc.l[0], b), lerp(pp.l[1], pc.l[1], b)];
  const rh: V2 = [lerp(pp.r[0], pc.r[0], b) + wig, lerp(pp.r[1], pc.r[1], b) + (cur.pose === 'wave' ? Math.cos(t * 11) * 8 : 0)];
  const mood = cur.mood;
  const bob = Math.sin(t * 2.2) * 6;
  const speaking = SPEAK.some(([a, c]) => t >= a && t <= c);
  const mouthOpen = speaking ? 4 + 11 * Math.abs(Math.sin(t * 17)) : 0;
  const blink = t % 3.1 < 0.12 ? 0.1 : 1;
  const browL = mood === 'worried' ? [150, 102, 188, 86] : mood === 'happy' ? [150, 90, 188, 86] : [150, 92, 188, 92];
  const browR = mood === 'worried' ? [250, 102, 212, 86] : mood === 'happy' ? [250, 90, 212, 86] : [250, 92, 212, 92];
  const mouth =
    mood === 'worried' ? 'M 178 168 Q 200 154 222 168' : mood === 'happy' ? 'M 170 156 Q 200 190 230 156' : 'M 180 162 Q 200 172 220 162';
  const pm = prog(t, 0.0, 0.5);
  return (
    <div
      style={{
        position: 'absolute',
        left,
        top,
        width: 400 * scale,
        height: 440 * scale,
        overflow: 'hidden',
        opacity: pm,
        filter: rim ? 'drop-shadow(10px 0 0 rgba(255,122,47,0.55))' : 'none',
      }}
    >
      <svg width={400 * scale} height={560 * scale} viewBox="0 0 400 560" style={{transform: `translateY(${bob * scale}px)`}}>
        {/* body */}
        <path d="M 100 255 Q 200 215 300 255 L 328 520 Q 200 548 72 520 Z" fill={C.navy2} stroke={C.navy3} strokeWidth={6} />
        <path d="M 120 400 L 280 400 L 296 470 L 104 470 Z" fill={C.navy3} opacity={0.9} />
        <path d="M 150 240 Q 200 285 250 240" fill="none" stroke={C.navy3} strokeWidth={14} strokeLinecap="round" />
        <line x1={182} y1={262} x2={178} y2={322} stroke={C.cream} strokeWidth={6} strokeLinecap="round" />
        <line x1={218} y1={262} x2={222} y2={322} stroke={C.cream} strokeWidth={6} strokeLinecap="round" />
        {/* arms */}
        <path d={armPath([118, 262], lh, -1)} fill="none" stroke={C.navy2} strokeWidth={50} strokeLinecap="round" />
        <path d={armPath([118, 262], lh, -1)} fill="none" stroke={C.navy3} strokeWidth={4} strokeLinecap="round" opacity={0.7} />
        <path d={armPath([282, 262], rh, 1)} fill="none" stroke={C.navy2} strokeWidth={50} strokeLinecap="round" />
        <path d={armPath([282, 262], rh, 1)} fill="none" stroke={C.navy3} strokeWidth={4} strokeLinecap="round" opacity={0.7} />
        <circle cx={lh[0]} cy={lh[1]} r={27} fill={C.cream} />
        <circle cx={rh[0]} cy={rh[1]} r={27} fill={C.cream} />
        {/* neck + hood + head */}
        <rect x={178} y={190} width={44} height={50} rx={14} fill="#E8D6BC" />
        <circle cx={200} cy={128} r={108} fill={C.navy2} stroke={C.navy3} strokeWidth={6} />
        <circle cx={200} cy={124} r={84} fill={C.cream} />
        <circle cx={150} cy={146} r={14} fill="#FFB08A" opacity={0.35} />
        <circle cx={250} cy={146} r={14} fill="#FFB08A" opacity={0.35} />
        <ellipse cx={172} cy={118} rx={10} ry={14 * blink} fill="#1B2240" />
        <ellipse cx={228} cy={118} rx={10} ry={14 * blink} fill="#1B2240" />
        <line x1={browL[0]} y1={browL[1]} x2={browL[2]} y2={browL[3]} stroke="#1B2240" strokeWidth={7} strokeLinecap="round" />
        <line x1={browR[0]} y1={browR[1]} x2={browR[2]} y2={browR[3]} stroke="#1B2240" strokeWidth={7} strokeLinecap="round" />
        {speaking ? (
          <ellipse cx={200} cy={166} rx={19} ry={mouthOpen} fill="#5A2B2B" />
        ) : (
          <path d={mouth} fill="none" stroke="#5A2B2B" strokeWidth={7} strokeLinecap="round" />
        )}
      </svg>
    </div>
  );
};

/* ---------------------------- CAPTIONS ---------------------------- */
type Cap = {a: number; b: number; text: string; hl?: string[]};
const CAPS: Cap[] = [
  {a: 0.14, b: 1.28, text: 'Job ravadam ledha?', hl: ['job', 'ravadam']},
  {a: 1.32, b: 2.94, text: 'Aithe okka vishayam gurthupettukondi…', hl: ['vishayam', 'gurthupettukondi']},
  {a: 2.98, b: 4.6, text: 'Just skills nerchukunte saripodu.', hl: ['skills', 'saripodu']},
  {a: 4.8, b: 6.62, text: 'Companies ki meeru aa skills ni', hl: ['companies', 'skills']},
  {a: 6.66, b: 8.82, text: 'real-world lo use cheyadam ravali...', hl: ['real', 'world', 'use']},
  {a: 8.84, b: 11.0, text: 'Anduke meeru three things meedha focus cheyyali:', hl: ['three', 'things', 'focus']},
  {a: 11.03, b: 12.15, text: 'First – Strong technical skills.', hl: ['strong', 'technical', 'skills']},
  {a: 12.24, b: 13.2, text: 'Second – Real-world projects.', hl: ['real', 'world', 'projects']},
  {a: 13.42, b: 14.6, text: 'Third – Communication', hl: ['communication']},
  {a: 14.64, b: 16.42, text: '2027 lo job target chestunnara?', hl: ['2027', 'job', 'target']},
  {a: 16.43, b: 17.57, text: 'Aithe job-ready avvadaniki complete roadmap kosam', hl: ['job', 'ready', 'roadmap']},
  {a: 17.59, b: 18.78, text: 'mana channel lo full video vundhi!', hl: ['channel', 'full', 'video']},
  {a: 19.11, b: 20.82, text: 'Check cheyandi...', hl: ['check']},
  {a: 20.85, b: 22.55, text: 'Ilanti informative videos kosam mana channel ni subscribe cheyandi...', hl: ['subscribe', 'channel']},
];
const Captions: React.FC<{t: number}> = ({t}) => {
  const cap = CAPS.find((c) => t >= c.a && t < c.b);
  if (!cap) return null;
  const p = prog(t, cap.a, 0.2);
  const fo = 1 - lin(t, cap.b - 0.1, 0.1);
  return (
    <div style={{position: 'absolute', left: 80, top: 1335, width: 920, minHeight: 150, display: 'flex', alignItems: 'center', justifyContent: 'center', opacity: Math.min(p, fo), transform: `translateY(${(1 - p) * 24}px)`}}>
      <div style={{background: 'rgba(5,10,30,0.88)', border: `3px solid ${C.navy3}`, borderRadius: 34, padding: '22px 36px', textAlign: 'center', fontFamily: POP, fontWeight: 600, fontSize: 46, lineHeight: 1.27, color: '#fff', boxShadow: '0 16px 36px rgba(0,0,0,0.45)'}}>
        {cap.text.split(/(\s+)/).map((w, i) => {
          const clean = w.toLowerCase().replace(/[^a-z0-9]/g, '');
          const on = cap.hl?.includes(clean);
          return (
            <span key={i} style={{color: on ? C.yellow : undefined, fontWeight: on ? 800 : undefined}}>
              {w}
            </span>
          );
        })}
      </div>
    </div>
  );
};

/* --------------------------- BACKGROUND --------------------------- */
const Background: React.FC<{frame: number; t: number}> = ({frame, t}) => {
  const drift = (frame * 0.4) % 90;
  const dots = Array.from({length: 18}, (_, i) => {
    const x = (i * 197) % 1080;
    const y = 1900 - (((i * 311 + frame * (1.2 + (i % 4) * 0.5)) % 1900));
    return <div key={i} style={{position: 'absolute', left: x, top: y, width: 8 + (i % 3) * 4, height: 8 + (i % 3) * 4, borderRadius: '50%', background: i % 2 ? C.cyan : C.orange, opacity: 0.22}} />;
  });
  return (
    <AbsoluteFill style={{background: `linear-gradient(180deg, #0A1330 0%, #12225A 55%, #0A1330 100%)`}}>
      <AbsoluteFill
        style={{
          backgroundImage: 'linear-gradient(rgba(53,208,255,0.07) 2px, transparent 2px), linear-gradient(90deg, rgba(53,208,255,0.07) 2px, transparent 2px)',
          backgroundSize: '90px 90px',
          backgroundPosition: `${drift}px ${drift}px`,
        }}
      />
      <div style={{position: 'absolute', left: -200, top: 760, width: 800, height: 800, borderRadius: '50%', background: 'radial-gradient(circle, rgba(255,122,47,0.35), rgba(255,122,47,0) 68%)'}} />
      <div style={{position: 'absolute', right: -260, top: 120, width: 760, height: 760, borderRadius: '50%', background: 'radial-gradient(circle, rgba(53,208,255,0.22), rgba(53,208,255,0) 68%)'}} />
      {dots}
      {/* progress bar */}
      <div style={{position: 'absolute', left: 70, top: 70, width: 940, height: 12, borderRadius: 99, background: 'rgba(255,255,255,0.15)'}}>
        <div style={{width: `${(t / 22.6) * 100}%`, height: '100%', borderRadius: 99, background: `linear-gradient(90deg, ${C.cyan}, ${C.orange})`}} />
      </div>
    </AbsoluteFill>
  );
};

/* ------------------------------ SCENES ------------------------------ */
// S1: hook
const S1: React.FC<{t: number}> = ({t}) => {
  const rej = [
    ['Application Rejected', 0.55],
    ['Not selected', 0.8],
    ['No response…', 1.05],
  ] as const;
  return (
    <>
      <Title t={t} top={170} until={1.55} lines={[
        {text: 'JOB', at: 0.14, size: 230, color: C.orange},
        {text: 'RAVADAM LEDHA?', at: 0.14, size: 94, color: C.white},
      ]} />
      {rej.map(([txt, at], i) => (
        <Card key={i} t={t} at={at} x={400} y={600 + i * 125} w={620} h={108} color={C.red} from="right" style={{borderRadius: 28}}>
          <Stk hex="274c" size={56} style={{position: 'absolute', left: 24, top: 26}} />
          <div style={{position: 'absolute', left: 100, top: 26, fontFamily: POP, fontWeight: 700, fontSize: 40, color: '#fff'}}>{txt}</div>
        </Card>
      ))}
    </>
  );
};

// S2: remember one thing + just skills not enough
const SKILLS = ['Python', 'SQL', 'React', 'ML'];
const S2: React.FC<{t: number}> = ({t}) => {
  const stamp = pop(t, 3.92);
  const dim = t > 3.95 ? 0.45 : 1;
  const bulb = pop(t, 1.9);
  return (
    <>
      <Title t={t} top={190} until={2.95} lines={[
        {text: 'OKKA VISHAYAM', at: 1.32, size: 112, color: C.white},
        {text: 'GURTHUPETTUKONDI', at: 1.5, size: 78, color: C.orange},
      ]} />
      {t < 2.95 && <Stk hex="1f4a1" size={240} style={{position: 'absolute', left: 700, top: 520, transform: `scale(${bulb}) rotate(${(1 - bulb) * 20}deg)`, filter: 'drop-shadow(0 0 40px rgba(255,210,77,0.7))'}} />}
      <Title t={t} top={190} lines={[
        {text: 'JUST SKILLS', at: 2.98, size: 140, color: C.white},
        {text: 'nerchukunte…', at: 3.05, size: 76, color: C.cyan, weight: 700},
      ]} />
      {SKILLS.map((s, i) => {
        const at = 3.1 + i * 0.2;
        const p = pop(t, at);
        if (p <= 0) return null;
        const x = 440 + (i % 2) * 290;
        const y = 560 + Math.floor(i / 2) * 150;
        return (
          <div key={s} style={{position: 'absolute', left: x, top: y, width: 260, height: 110, borderRadius: 30, background: C.navy3, border: `4px solid ${C.cyan}`, color: '#fff', fontFamily: POP, fontWeight: 800, fontSize: 46, display: 'flex', alignItems: 'center', justifyContent: 'center', transform: `scale(${p})`, opacity: dim}}>
            {s}
          </div>
        );
      })}
      {t >= 3.92 && (
        <div
          style={{
            position: 'absolute',
            left: 400,
            top: 650,
            width: 620,
            textAlign: 'center',
            fontFamily: POP,
            fontWeight: 800,
            fontSize: 74,
            color: C.red,
            border: `10px solid ${C.red}`,
            borderRadius: 24,
            padding: '8px 0',
            background: 'rgba(10,19,48,0.85)',
            transform: `rotate(-10deg) scale(${0.6 + 0.4 * stamp + (1 - Math.min(1, stamp)) * 0.9})`,
            opacity: Math.min(1, stamp * 2),
          }}
        >
          NOT ENOUGH ✗
        </div>
      )}
    </>
  );
};

// S3: real-world use inside companies
const S3: React.FC<{t: number}> = ({t}) => {
  const bld = pop(t, 5.0);
  const flow = prog(t, 7.35, 0.8);
  const chk = pop(t, 8.2);
  const spin = (t - 7.6) * 140;
  const chips = ['Python', 'SQL', 'React'];
  return (
    <>
      <Title t={t} top={190} lines={[
        {text: 'COMPANIES', at: 4.8, size: 120, color: C.white},
        {text: 'REAL-WORLD USE', at: 6.66, size: 92, color: C.cyan},
      ]} />
      <Stk hex="1f3e2" size={330} style={{position: 'absolute', left: 690, top: 520, transform: `scale(${bld})`, filter: 'drop-shadow(0 20px 40px rgba(0,0,0,0.5))'}} />
      {t >= 7.6 && <Stk hex="2699" size={110} style={{position: 'absolute', left: 640, top: 480, transform: `rotate(${spin}deg)`, opacity: 0.95}} />}
      {t >= 8.2 && <Stk hex="2705" size={150} style={{position: 'absolute', left: 860, top: 440, transform: `scale(${chk})`}} />}
      {chips.map((c, i) => {
        const at = 5.6 + i * 0.25;
        const p = pop(t, at);
        if (p <= 0) return null;
        const x0 = 420;
        const x = lerp(x0, 760, flow) ;
        return (
          <div key={c} style={{position: 'absolute', left: x, top: 560 + i * 120, width: 230, height: 92, borderRadius: 26, background: C.navy3, border: `4px solid ${C.cyan}`, color: '#fff', fontFamily: POP, fontWeight: 800, fontSize: 42, display: 'flex', alignItems: 'center', justifyContent: 'center', transform: `scale(${p * (1 - 0.35 * flow)})`, opacity: 1 - 0.85 * lin(t, 8.0, 0.3)}}>
            {c}
          </div>
        );
      })}
      {t >= 6.7 && (
        <svg width={300} height={60} style={{position: 'absolute', left: 560, top: 890, opacity: prog(t, 6.7, 0.4)}}>
          <line x1={10} y1={30} x2={250} y2={30} stroke={C.orange} strokeWidth={10} strokeDasharray="20 14" strokeDashoffset={-t * 80} strokeLinecap="round" />
          <polygon points="250,8 292,30 250,52" fill={C.orange} />
        </svg>
      )}
    </>
  );
};

// S4: big three
const S4: React.FC<{t: number}> = ({t}) => {
  const p = pop(t, 9.55);
  const dots = [10.0, 10.5, 10.9];
  return (
    <>
      <Title t={t} top={190} lines={[{text: 'FOCUS ON', at: 8.9, size: 100, color: C.white}]} />
      <div style={{position: 'absolute', left: 0, width: 1080, top: 330, textAlign: 'center', fontFamily: POP, fontWeight: 800, fontSize: 470, lineHeight: 1, color: C.orange, transform: `scale(${p})`, textShadow: `0 0 80px ${C.orange}88`}}>3</div>
      <div style={{position: 'absolute', left: 0, width: 1080, top: 800, textAlign: 'center', fontFamily: POP, fontWeight: 800, fontSize: 100, color: C.cyan, opacity: prog(t, 9.97, 0.3)}}>THINGS</div>
      <div style={{position: 'absolute', left: 0, width: 1080, top: 960, display: 'flex', justifyContent: 'center', gap: 34}}>
        {dots.map((d, i) => (
          <div key={i} style={{width: 46, height: 46, borderRadius: '50%', border: `5px solid ${C.cyan}`, background: t >= d ? C.green : 'transparent', transform: `scale(${t >= d ? 0.9 + 0.3 * pop(t, d) : 1})`}} />
        ))}
      </div>
    </>
  );
};

// S5: three cards
const CARDS = [
  {n: '1', lab: 'FIRST', title: 'STRONG TECHNICAL SKILLS', hex: '1f4bb', color: C.cyan, at: 11.03},
  {n: '2', lab: 'SECOND', title: 'REAL-WORLD PROJECTS', hex: '1f6e0', color: C.orange, at: 12.24},
  {n: '3', lab: 'THIRD', title: 'COMMUNICATION', hex: '1f4ac', color: C.green, at: 13.42},
];
const S5: React.FC<{t: number}> = ({t}) => (
  <>
    <Title t={t} top={180} lines={[{text: '3 THINGS TO FOCUS', at: 10.95, size: 84, color: C.white}]} />
    {CARDS.map((c, i) => (
      <Card key={c.n} t={t} at={c.at} x={70} y={330 + i * 190} w={940} h={168} color={c.color} from="right">
        <div style={{position: 'absolute', left: 26, top: 30, width: 108, height: 108, borderRadius: '50%', background: c.color, color: C.navy, fontFamily: POP, fontWeight: 800, fontSize: 70, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>{c.n}</div>
        <div style={{position: 'absolute', left: 160, top: 18, fontFamily: POP, fontWeight: 700, fontSize: 30, color: c.color, letterSpacing: 4}}>{c.lab}</div>
        <div style={{position: 'absolute', left: 160, top: 56, width: 600, fontFamily: POP, fontWeight: 800, fontSize: 50, color: '#fff', lineHeight: 1.06}}>{c.title}</div>
        <Stk hex={c.hex} size={120} style={{position: 'absolute', right: 28, top: 24}} />
      </Card>
    ))}
  </>
);

// S6: 2027 + roadmap
const NODES: {x: number; y: number; label: string; at: number}[] = [
  {x: 140, y: 800, label: 'SKILLS', at: 16.7},
  {x: 400, y: 640, label: 'PROJECTS', at: 17.1},
  {x: 660, y: 800, label: 'COMMUNICATION', at: 17.5},
  {x: 900, y: 640, label: 'JOB', at: 17.9},
];
const VideoCard: React.FC<{t: number; at: number; x: number; y: number; w: number; scale?: number; pulse?: boolean}> = ({t, at, x, y, w, pulse}) => {
  const p = pop(t, at);
  if (p <= 0) return null;
  const h = Math.round(w * 0.56);
  const pl = pulse ? 1 + Math.sin(t * 8) * 0.07 : 1;
  return (
    <div style={{position: 'absolute', left: x, top: y, width: w, height: h, borderRadius: 30, overflow: 'hidden', border: `5px solid ${C.white}`, boxShadow: '0 24px 60px rgba(0,0,0,0.55)', transform: `scale(${0.7 + 0.3 * p})`, opacity: Math.min(1, p * 1.6), background: `linear-gradient(135deg, ${C.navy3}, ${C.navy})`}}>
      <div style={{position: 'absolute', left: 24, top: 18, fontFamily: POP, fontWeight: 800, fontSize: Math.round(w * 0.08), color: C.yellow, lineHeight: 1.05}}>
        JOB-READY
        <br />
        ROADMAP
      </div>
      <div style={{position: 'absolute', left: '50%', top: '58%', width: w * 0.26, height: w * 0.18, marginLeft: -(w * 0.13), marginTop: -(w * 0.09), borderRadius: 24, background: '#FF0033', transform: `scale(${pl})`, display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 10px 30px rgba(255,0,51,0.5)'}}>
        <div style={{width: 0, height: 0, borderTop: `${w * 0.045}px solid transparent`, borderBottom: `${w * 0.045}px solid transparent`, borderLeft: `${w * 0.075}px solid #fff`, marginLeft: w * 0.015}} />
      </div>
    </div>
  );
};
const S6: React.FC<{t: number}> = ({t}) => {
  const drawP = prog(t, 16.5, 1.5);
  const pathD = 'M 140 800 C 240 800 300 640 400 640 C 520 640 540 800 660 800 C 770 800 800 640 900 640';
  return (
    <>
      <Title t={t} top={180} until={16.4} lines={[
        {text: '2027 LO', at: 14.64, size: 150, color: C.orange},
        {text: 'JOB TARGET?', at: 15.0, size: 116, color: C.white},
      ]} />
      {t < 16.4 && <Stk hex="1f4c5" size={260} style={{position: 'absolute', left: 690, top: 560, transform: `scale(${pop(t, 14.9)})`, filter: 'drop-shadow(0 20px 40px rgba(0,0,0,0.5))'}} />}
      <Title t={t} top={180} lines={[
        {text: 'JOB-READY', at: 16.43, size: 118, color: C.cyan},
        {text: 'ROADMAP', at: 16.5, size: 118, color: C.white},
      ]} />
      {t >= 16.43 && (
        <svg width={1080} height={900} viewBox="0 0 1080 900" style={{position: 'absolute', left: 0, top: 430}}>
          <g transform="translate(0,-500)">
            <path d={pathD} fill="none" stroke="rgba(255,255,255,0.18)" strokeWidth={26} strokeLinecap="round" />
            <path d={pathD} fill="none" stroke={C.orange} strokeWidth={14} strokeLinecap="round" strokeDasharray="1300" strokeDashoffset={1300 * (1 - drawP)} />
            {NODES.map((n, i) => {
              const p = pop(t, n.at);
              return (
                <g key={i} transform={`translate(${n.x},${n.y}) scale(${p})`}>
                  <circle r={34} fill={i === 3 ? C.green : C.cyan} stroke="#fff" strokeWidth={8} />
                  <text y={-56} textAnchor="middle" fontFamily={POP} fontWeight={800} fontSize={i === 2 ? 28 : 34} fill="#fff">{n.label}</text>
                </g>
              );
            })}
          </g>
        </svg>
      )}
      {t >= 17.9 && <Stk hex="1f3c1" size={90} style={{position: 'absolute', left: 935, top: 525, transform: `scale(${pop(t, 17.95)})`}} />}
      <VideoCard t={t} at={17.62} x={470} y={800} w={540} />
    </>
  );
};

// S7: check + subscribe
const Cursor: React.FC<{x: number; y: number; press: number}> = ({x, y, press}) => (
  <svg width={90} height={90} viewBox="0 0 24 24" style={{position: 'absolute', left: x, top: y, transform: `scale(${1 - 0.15 * press})`, filter: 'drop-shadow(0 6px 8px rgba(0,0,0,0.5))'}}>
    <path d="M5 2 L5 19 L9.5 14.8 L12.5 21.5 L15 20.4 L12 13.8 L18 13.5 Z" fill="#fff" stroke="#111" strokeWidth={1.2} strokeLinejoin="round" />
  </svg>
);
const S7: React.FC<{t: number}> = ({t}) => {
  const subd = t >= 21.55;
  const bp = pop(t, 20.85);
  const bell = t >= 21.66 ? Math.sin((t - 21.66) * 26) * 22 * Math.exp(-(t - 21.66) * 2.2) : 0;
  const cur = prog(t, 21.0, 0.55);
  const press = t >= 21.5 && t < 21.7 ? 1 : 0;
  const bx = 470;
  const by = 930;
  return (
    <>
      <Title t={t} top={180} lines={[
        {text: 'CHECK', at: 19.11, size: 140, color: C.white},
        {text: 'CHEYANDI', at: 19.2, size: 140, color: C.orange},
      ]} />
      <VideoCard t={t} at={19.4} x={420} y={560} w={600} pulse />
      {t >= 19.5 && (
        <svg width={120} height={90} viewBox="0 0 120 90" style={{position: 'absolute', left: 250 + Math.sin(t * 7) * 14, top: 690}}><polygon points="0,25 70,25 70,0 120,45 70,90 70,65 0,65" fill={C.yellow} /></svg>
      )}
      {bp > 0 && (
        <div style={{position: 'absolute', left: bx, top: by, width: 550, height: 130, borderRadius: 30, background: subd ? '#3A4670' : '#FF0033', color: '#fff', fontFamily: POP, fontWeight: 800, fontSize: 52, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 16, transform: `scale(${bp * (press ? 0.93 : 1)})`, boxShadow: subd ? 'none' : '0 14px 40px rgba(255,0,51,0.55)'}}>
          {subd ? 'SUBSCRIBED ✓' : 'SUBSCRIBE'}
          <Stk hex="1f514" size={70} style={{transform: `rotate(${bell}deg)`, transformOrigin: '50% 10%'}} />
        </div>
      )}
      {t >= 21.0 && t < 22.5 && <Cursor x={lerp(980, bx + 330, cur)} y={lerp(1250, by + 70, cur)} press={press} />}
    </>
  );
};

/* ------------------------------- ROOT ------------------------------- */
const SHAKES = [0.14, 3.92, 9.52, 11.03, 12.24, 13.42];
export const Reel: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const [handle] = useState(() => delayRender('fonts'));
  React.useEffect(() => {
    const faces = [500, 600, 700, 800].map(
      (w) => new FontFace('Poppins', `url(${staticFile(`fonts/poppins-latin-${w}-normal.woff2`)})`, {weight: String(w)})
    );
    Promise.all(faces.map((f) => f.load()))
      .then((l) => {
        l.forEach((f) => document.fonts.add(f));
        continueRender(handle);
      })
      .catch(() => continueRender(handle));
  }, [handle]);

  let sx = 0;
  let sy = 0;
  SHAKES.forEach((s) => {
    if (t >= s && t < s + 0.5) {
      const a = 14 * Math.exp(-(t - s) * 9);
      sx += Math.sin((t - s) * 70) * a;
      sy += Math.cos((t - s) * 83) * a;
    }
  });
  const rim = (t >= 10.95 && t < 14.6) || t >= 19.08;

  return (
    <AbsoluteFill style={{fontFamily: POP}}>
      <Audio src={staticFile('mix.mp3')} />
      <Background frame={frame} t={t} />
      <AbsoluteFill style={{transform: `translate(${sx}px, ${sy}px)`}}>
        <Scene t={t} a={0} b={1.55}>
          <S1 t={t} />
        </Scene>
        <Scene t={t} a={1.28} b={4.62}>
          <S2 t={t} />
        </Scene>
        <Scene t={t} a={4.75} b={8.9}>
          <S3 t={t} />
        </Scene>
        <Scene t={t} a={8.8} b={11.1}>
          <S4 t={t} />
        </Scene>
        <Scene t={t} a={10.95} b={14.7}>
          <S5 t={t} />
        </Scene>
        <Scene t={t} a={14.6} b={19.05}>
          <S6 t={t} />
        </Scene>
        <Scene t={t} a={19.05} b={22.72}>
          <S7 t={t} />
        </Scene>
        <Char t={t} left={20} top={880} scale={1} rim={rim} />
      </AbsoluteFill>
      <Captions t={t} />
    </AbsoluteFill>
  );
};
